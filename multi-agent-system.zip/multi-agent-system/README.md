streamlit==1.28.0
google-generativeai==0.3.2
python-dotenv==1.0.0
pillow==10.0.1
pandas==2.1.1
numpy==1.24.3